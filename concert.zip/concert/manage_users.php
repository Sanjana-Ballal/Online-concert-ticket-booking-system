<?php
$connection=mysqli_connect("localhost","root","","cse480");

// Fetch all users
$sql = "SELECT * FROM user";
$result = mysqli_query($connection, $sql);
?>

<html>
    <head>
    <title>User Data</title>
    <style>
        body {
            background-image: url("img/party2.jpg");
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 20px;
            background-color: #f4f4f4;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            height: 100vh;

        }

        .container {
            max-width: 800px;
            width: 100%;
            text-align: center;
        }

        h2 {
            color: #333;
            font-family: "Arial Black", sans-serif;
            font-size: 28px;
            margin-bottom: 20px;
        }

        table {
            margin: 0 auto;
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        th, td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }

        th {
            background-color: #f2f2f2;
        }

        tr {
            background-color: #f2f2f2;
        }


        .btn-primary {
            background-color: #007bff;
            color: white;
            border: none;
            padding: 10px 20px;
            text-align: center;
            text-decoration: none;
            display: inline-block;
            font-size: 16px;
            margin-top: 20px;
            cursor: pointer;
            border-radius: 5px;
        }

        .btn-primary:hover {
            background-color: #0056b3;
        }

        .btn-primary:active {
            background-color: #0056b3;
            transform: translateY(1px);
        }
    </style>
    </head>
<body>
<h2>User Data</h2>

<!-- Display Users -->
<table border="1">
    <tr>
        <th>User Name</th>
        <th>User Email</th>
        <th>User Password</th>
    </tr>
    <?php while($row = mysqli_fetch_assoc($result)): ?>
    <tr>
        <td><?php echo $row['name']; ?></td>
        <td><?php echo $row['mail']; ?></td>
        <td><?php echo $row['password']; ?></td>
    </tr>
    <?php endwhile; ?>
</table>
<a href="admin_panel.php">
        <button class="btn-primary" value="logout">BACK</button>
    </a>
</body>
</html>
