-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: localhost:8889
-- Generation Time: Apr 06, 2019 at 08:40 AM
-- Server version: 5.7.23
-- PHP Version: 7.2.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `signup`
--

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `name` text NOT NULL,
  `mail` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`name`, `mail`, `password`) VALUES
('Nishant', 'nishant@gmail.com', 'Nishant@12'),
('priyank', 'priyank88@gmail.com', 'Pk@123456'),
('Priyank Kanani', 'priyank@gmail.com', 'Pk@123456'),
('priyan', 'priyankk@gmail.com', 'pk@12345'),
('Sahil Ganeriwal', 'sahilganeriwal@hotmail.com', 'S@hil2726'),
('vipul', 'vipulnagpal51@gmail.com', 'Vi$jgsvd4');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD UNIQUE KEY `UNIQUE` (`mail`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

-- Table structure for table `admin`
CREATE TABLE `admin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table `admin`
INSERT INTO `admin` (`username`, `password`) VALUES
('admin', '12345');

-- Table structure for table `tickets`
CREATE TABLE `tickets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `concert_name` varchar(255) NOT NULL,
  `venue` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table `tickets` 
INSERT INTO `tickets` (`id`, `date`, `concert_name`, `venue`) VALUES
(1, '2024-04-05', 'Vijay Prakash Concert', 'Bangalore Palace, Bangalore'),
(2, '2024-04-09', 'Rajesh Krishnan Concert', 'Jayamahal Palace, Bangalore'),
(3, '2024-04-20', 'Raghu Dixit Concert', 'BMS College, Bangalore'),
(4, '2024-04-25', 'Shreya Ghoshal Concert', 'Phoenix Marketcity, Bangalore'),
(5, '2024-04-30', 'Sonu Nigam Concert', 'Bhartiya Mall of Bangalore, Bangalore'),
(6, '2024-05-04', 'Arijit Singh Concert', 'Good Shepherd Auditorium, Bangalore'),
(7, '2024-05-10', 'K S Chitra Concert', 'Phoenix Marketcity, Bangalore'),
(8, '2024-05-16', 'Sunidhi Chauhan Concert', 'IISc, Bangalore'),
(9, '2024-05-24', 'Shankar Mahadevan Concert', 'Indira Nagar Club, Bangalore'),
(10, '2024-05-31', 'A R Rahman Concert', 'Mall of Asia, Bangalore'),
(11, '2024-06-06', 'Armaan Malik Concert', 'Phoenix Marketcity, Bangalore'),
(12, '2024-06-18', 'Kailash Kher Concert', 'Orion Mall, Bangalore'),
(13, '2024-06-23', 'Sanjith Hegde Concert', 'Nandi Link Grounds, Bangalore'),
(14, '2024-06-30', 'Atif Aslam Concert', 'Chowdiah Memorial Hall, Bangalore');




