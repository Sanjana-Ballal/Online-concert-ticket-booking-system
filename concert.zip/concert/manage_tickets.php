<?php
$connection=mysqli_connect("localhost","root","","cse480");

// Add ticket
if(isset($_POST['add_submit'])) {
    $date = $_POST['date'];
    $concert_name = $_POST['concert_name'];
    $venue = $_POST['venue'];
    $sql = "INSERT INTO tickets (date, concert_name, venue) VALUES ('$date', '$concert_name', '$venue')";
    mysqli_query($connection, $sql);
}

// Edit ticket
if(isset($_POST['edit_submit'])) {
    $id = $_POST['id'];
    $date = $_POST['date'];
    $concert_name = $_POST['concert_name'];
    $venue = $_POST['venue'];
    $sql = "UPDATE tickets SET date='$date', concert_name='$concert_name', venue='$venue' WHERE id='$id'";
    mysqli_query($connection, $sql);
}

// Delete ticket
if(isset($_POST['delete_submit'])) {
    $id = $_POST['id'];
    $sql = "DELETE FROM tickets WHERE id='$id'";
    mysqli_query($connection, $sql);
}

// Fetch all tickets
$sql = "SELECT * FROM tickets";
$result = mysqli_query($connection, $sql);
?>

<html>
<body>
<h2>Add/Edit/Delete Concert Tickets</h2>

<!-- Add Ticket Form -->
<h3>Add Ticket</h3>
<form action="" method="post">
    <input type="text" name="date" placeholder="Date" required><br>
    <input type="text" name="concert_name" placeholder="Concert Name" required><br>
    <input type="text" name="venue" placeholder="Venue" required><br>
    <input type="submit" name="add_submit" value="Add Ticket">
</form>

<!-- Display Tickets -->
<h3>Concert Tickets</h3>
<table border="1">
    <tr>
        <th>ID</th>
        <th>Date</th>
        <th>Concert Name</th>
        <th>Venue</th>
        <th>Edit</th>
        <th>Delete</th>
    </tr>
    <?php while($row = mysqli_fetch_assoc($result)): ?>
    <tr>
        <td><?php echo $row['id']; ?></td>
        <td><?php echo $row['date']; ?></td>
        <td><?php echo $row['concert_name']; ?></td>
        <td><?php echo $row['venue']; ?></td>
        <td>
            <form action="" method="post">
                <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
                <input type="text" name="date" placeholder="Date" required><br>
                <input type="text" name="concert_name" placeholder="Concert Name" required><br>
                <input type="text" name="venue" placeholder="Venue" required><br>
                <input type="submit" name="edit_submit" value="Edit">
            </form>
        </td>
        <td>
            <form action="" method="post">
                <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
                <input type="submit" name="delete_submit" value="Delete">
            </form>
        </td>
    </tr>
    <?php endwhile; ?>
</table>
<a href="admin_panel.php">
        <button class="btn-primary" value="logout">BACK</button>
    </a>
</body>
</html>
