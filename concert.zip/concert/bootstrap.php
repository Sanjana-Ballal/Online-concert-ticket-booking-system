	<meta content="width=device-width, initial-scale=1" name="viewport">
	<meta content="Webflow" name="generator">
	<link href="https://daks2k3a4ib2z.cloudfront.net/560eb94ab52962bd77dfcf14/css/template-method.webflow.cd9516ad2.css" rel="stylesheet" type="text/css">
	<script src="https://ajax.googleapis.com/ajax/libs/webfont/1.4.7/webfont.js"></script>
	<link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Roboto:300,regular,500%7CRoboto+Slab:regular">
	<script type="text/javascript">WebFont.load({
	  google: {
	    families: ["Roboto:300,regular,500","Roboto Slab:regular"]
	  }
	});
	</script>
	<script src="https://daks2k3a4ib2z.cloudfront.net/0globals/modernizr-2.7.1.js" type="text/javascript"></script>
	<link href="img/logo1.png" rel="shortcut icon" type="image/x-icon">
	<link href="https://daks2k3a4ib2z.cloudfront.net/img/webclip.png" rel="apple-touch-icon">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js" type="text/javascript"></script>
	<script src="https://daks2k3a4ib2z.cloudfront.net/560eb94ab52962bd77dfcf14/js/webflow.57f4ffb2a.js" type="text/javascript"></script>