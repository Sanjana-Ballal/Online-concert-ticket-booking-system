<!DOCTYPE html>
<html>
<head>
    <title>Admin Login</title>
    <link rel="stylesheet" type="text/css" href="styles.css">
</head>
<body>
    <div class="login-box">
        <h2>Admin Login</h2>
        <form action="admin_login_process.php" method="post">
            <div class="textbox">
                <input type="text" placeholder="Username" name="username" required>
            </div>
            <div class="textbox">
                <input type="password" placeholder="Password" name="password" required>
            </div>
            <input class="btn" type="submit" value="Login">
        </form>
    </div>
</body>
</html>
